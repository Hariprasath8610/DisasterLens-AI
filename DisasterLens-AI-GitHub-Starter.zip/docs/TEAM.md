# Team Responsibilities

## Balasurya
- Stitch UI design
- Dashboard screens
- Map/risk visualizations
- Responsive UI

## Hariprasath
- Frontend implementation
- Backend/API implementation
- External data integration
- AI/LLM frontend-backend integration

## Aswath
- AI risk engine
- LLM assistant
- Prompt engineering
- AI/API integration
- GitHub repository and version control
