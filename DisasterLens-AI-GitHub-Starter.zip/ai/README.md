# AI / LLM

Owner: Aswath  
Integration: Aswath + Hariprasath

Place the disaster risk engine, prompts, LLM client and AI-related services here.
