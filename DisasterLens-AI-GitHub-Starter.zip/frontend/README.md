# Frontend

Owner: Hariprasath  
UI source/design: Balasurya (Stitch)

Place the Stitch-generated UI and frontend application here.
