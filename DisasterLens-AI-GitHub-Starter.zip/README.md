# DisasterLens AI

AI-powered local natural disaster risk intelligence platform.

## Team
- Balasurya — UI Developer (Stitch)
- Hariprasath — Frontend + Backend
- Aswath — AI/LLM + Git Management
- Hariprasath + Aswath — AI/LLM integration

## Project structure
- `frontend/` — UI and frontend application
- `backend/` — API and backend services
- `ai/` — risk engine, prompts and LLM integration
- `docs/` — project documentation

## Git workflow
Use feature branches:
- `ui/balasurya`
- `feat/hariprasath`
- `ai/aswath`

Keep `main` stable and merge tested features through pull requests.

## Getting started
This repository is a clean starter structure. Add the Stitch-generated frontend to `frontend/`, backend implementation to `backend/`, and AI/LLM implementation to `ai/`.
